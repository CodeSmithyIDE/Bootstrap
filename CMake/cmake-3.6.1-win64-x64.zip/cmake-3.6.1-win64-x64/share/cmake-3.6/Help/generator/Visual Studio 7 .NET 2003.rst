Visual Studio 7 .NET 2003
-------------------------

Deprecated.  Generates Visual Studio .NET 2003 project files.

.. note::
  This generator is deprecated and will be removed
  in a future version of CMake.  It will still be
  possible to build with VS 7.1 tools using the
  :generator:`NMake Makefiles` generator.
